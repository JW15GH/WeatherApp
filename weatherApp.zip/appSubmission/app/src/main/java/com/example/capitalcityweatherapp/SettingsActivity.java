package com.example.capitalcityweatherapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private Button buttonSave;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Get shared preferences instance
        sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        buttonSave = findViewById(R.id.btn_save);
        radioGroup = findViewById(R.id.radio_group_colors);

        // Set the current colour choice
        int selectedColorId = sharedPreferences.getInt("selectedColor", R.color.white);
        radioGroup.check(getRadioButtonId(selectedColorId));

        // Saves the colour selected by the user after the save button is clicked
        buttonSave.setOnClickListener(v -> {
            int selectedColorIdNew = getSelectedColorId();
            if (selectedColorIdNew != selectedColorId) {
                editor.putInt("selectedColor", selectedColorIdNew);
                editor.apply();
                int selectedColorNew = ContextCompat.getColor(getApplicationContext(), selectedColorIdNew);
                getWindow().getDecorView().getRootView().setBackgroundColor(selectedColorNew);

            }
            finish();
        });

        // Changes the activity's background colour
        int selectedColor = ContextCompat.getColor(getApplicationContext(), selectedColorId);
        getWindow().getDecorView().getRootView().setBackgroundColor(selectedColor);
    }


    // Returns ID of button which corresponds to given colour ID
    private int getRadioButtonId(int colorId) {
        switch (colorId) {
            case R.color.red:
                return R.id.radio_red;
            case R.color.green:
                return R.id.radio_green;
            case R.color.blue:
                return R.id.radio_blue;
            default:
                return R.id.radio_white;
        }
    }

    // Returns ID of current colour selected
    private int getSelectedColorId() {
        int selectedId = radioGroup.getCheckedRadioButtonId();
        switch (selectedId) {
            case R.id.radio_red:
                return R.color.red;
            case R.id.radio_green:
                return R.color.green;
            case R.id.radio_blue:
                return R.color.blue;
            default:
                return R.color.white;
        }
    }
}

