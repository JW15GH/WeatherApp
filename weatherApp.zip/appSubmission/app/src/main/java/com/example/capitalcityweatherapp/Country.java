package com.example.capitalcityweatherapp;

public class Country {
    private String land;

    public Country(String land) {
        this.land = land;
    }

    public String getLand() {
        return land;
    }
}
