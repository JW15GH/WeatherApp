package com.example.capitalcityweatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;



import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;


import java.util.ArrayList;


/**
 * A weather app which showcases the temperature of capital cities
 * from major tourist countries. Users are able to configure the
 * units and change the background colour
 *
 * @author James White
 * @version 1.0
 *
 */

public class MainActivity extends AppCompatActivity {

    private ArrayList<Capital> capitalArrayList;
    private ArrayList<Country> countryArrayList;
    private RecyclerView recyclerView;
    private RecyclerAdaptor.RecyclerViewClickListener listener;
    private String isCelsiusSelected = "Metric";
    private int selectedColorId;

    // Method called when activity is first created. Providing the user
    // interface and any necessary data that the activity needs to display.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycle);
        countryArrayList = new ArrayList<>();
        capitalArrayList = new ArrayList<>();

        setCountryInfo();
        setCapitalInfo();
        setAdaptor();
    }


    // Method called when activity is resumed and visible to user again
    @Override
    protected void onResume() {
        super.onResume();

        // Get the selected color from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);
        selectedColorId = sharedPreferences.getInt("selectedColor", R.color.white);

        // Set the background color of the activity
        int selectedColor = ContextCompat.getColor(getApplicationContext(), selectedColorId);
        ConstraintLayout layout = findViewById(R.id.activity_main_layout);
        layout.setBackgroundColor(selectedColor);
    }


    // Sets up the user interface of the main activity by creating a recycler adaptor object
    // and setting as the recycler view adaptor.
    private void setAdaptor() {
        setOnClickListener();
        RecyclerAdaptor adaptor = new RecyclerAdaptor(countryArrayList, listener);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adaptor);
    }


    // When a RecyclerView item is clicked, it retrieves the item's location and retrieves
    // the associated Capital object from the capitalArrayList. It then creates an intent
    // to start the ProfileActivity and passes the name of the capital and the isCelsiusSelected
    // variable.
    private void setOnClickListener() {
        listener = (v, position) -> {
            ArrayList<Capital> capitalArrayList = getCapitalArrayList();
            String capital = capitalArrayList.get(position).getName();
            Intent intent = new Intent(getApplicationContext(), ProfileActivity.class);
            intent.putExtra("capital", capital);
            intent.putExtra("isCelsiusSelected", isCelsiusSelected);
            startActivity(intent);
        };
    }

    // Populates an ArrayList with predefined major holiday destination countries
    private void setCountryInfo() {
        countryArrayList.add(new Country("England"));
        countryArrayList.add(new Country("Japan"));
        countryArrayList.add(new Country("China"));
        countryArrayList.add(new Country("Spain"));
        countryArrayList.add(new Country("Philippines"));
        countryArrayList.add(new Country("Thailand"));
        countryArrayList.add(new Country("France"));
        countryArrayList.add(new Country("Netherlands"));
        countryArrayList.add(new Country("Norway"));
        countryArrayList.add(new Country("Belgium"));
        countryArrayList.add(new Country("Australia"));
        countryArrayList.add(new Country("Kenya"));
        countryArrayList.add(new Country("Canada"));
        countryArrayList.add(new Country("Italy"));
        countryArrayList.add(new Country("Fiji"));
        countryArrayList.add(new Country("Brazil"));
        countryArrayList.add(new Country("Ghana"));
    }


    // A getter method that returns the capitalArrayList
    public ArrayList<Capital> getCapitalArrayList() {
        return capitalArrayList;
    }


    // Populates an ArrayList with predefined major holiday destination capital cities
    private void setCapitalInfo() {
        capitalArrayList.add(new Capital("London"));
        capitalArrayList.add(new Capital("Tokyo"));
        capitalArrayList.add(new Capital("Beijing"));
        capitalArrayList.add(new Capital("Madrid"));
        capitalArrayList.add(new Capital("Manila"));
        capitalArrayList.add(new Capital("Bangkok"));
        capitalArrayList.add(new Capital("Paris"));
        capitalArrayList.add(new Capital("Amsterdam"));
        capitalArrayList.add(new Capital("Oslo"));
        capitalArrayList.add(new Capital("Brussels"));
        capitalArrayList.add(new Capital("Canberra"));
        capitalArrayList.add(new Capital("Nairobi"));
        capitalArrayList.add(new Capital("Ottawa"));
        capitalArrayList.add(new Capital("Rome"));
        capitalArrayList.add(new Capital("Suva"));
        capitalArrayList.add(new Capital("Brasília"));
        capitalArrayList.add(new Capital("Accra"));
    }


    // Inflates the menu layout and adds items to it
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    // Called when an item is selected from the menu and checks the ID of the
    // item selected by the user. Changes variable value depending on what user
    // selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_celsius:
                isCelsiusSelected = "Metric";
                item.setChecked(true);
                return true;

            case R.id.menu_fahrenheit:
                isCelsiusSelected = "Imperial";
                item.setChecked(true);
                return true;

            case R.id.action_settings:
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
