package com.example.capitalcityweatherapp;

public class Capital {
    private String name;

    public Capital(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
