package com.example.capitalcityweatherapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdaptor extends RecyclerView.Adapter<RecyclerAdaptor.MyViewHolder> {
    private ArrayList<Country> countryList;
    private RecyclerViewClickListener listener;

    public RecyclerAdaptor(ArrayList<Country> countryList, RecyclerViewClickListener listener) {
        this.countryList = countryList;
        this.listener = listener;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder  implements View.OnClickListener{
        private TextView nameTxt;

        public MyViewHolder(final View view){
            super(view);
            nameTxt = view.findViewById(R.id.textView2);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            listener.onClick(view, getAdapterPosition());
        }
    }


    //Creates a new  RecyclerView.ViewHolder object that represents a new item in the RecyclerView
    @Override
    public RecyclerAdaptor.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdaptor.MyViewHolder holder, int position) {
        String name = countryList.get(position).getLand();
        holder.nameTxt.setText(name);
    }

    @Override
    public int getItemCount() {
        return countryList.size();
    }

    public interface RecyclerViewClickListener{
        void onClick(View v, int position);
    }
}
