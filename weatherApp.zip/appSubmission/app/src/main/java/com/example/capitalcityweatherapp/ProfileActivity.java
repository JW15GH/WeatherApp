package com.example.capitalcityweatherapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;


public class ProfileActivity extends AppCompatActivity {

    private TextView tempTextView;
    private int selectedColorId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);

        TextView nameTxt = findViewById(R.id.nameTextView);
        String capital = getIntent().getStringExtra("capital");
        nameTxt.setText(capital != null ? capital : "Capital not set");

        tempTextView = findViewById(R.id.temp);
        String city = getIntent().getStringExtra("capital");
        String units = getIntent().getStringExtra("isCelsiusSelected");

        fetchWeatherInfo(city, units);

    }
    @Override
    protected void onResume() {
        super.onResume();

        // Get the colour the users selected from the preferences button from shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);
        selectedColorId = sharedPreferences.getInt("selectedColor", R.color.white);

        // Change the background colour for the activity
        int selectedColor = ContextCompat.getColor(getApplicationContext(), selectedColorId);
        ConstraintLayout layout = findViewById(R.id.profile_settings_layout);
        layout.setBackgroundColor(selectedColor);
    }

    // Performs network operations in the background and returns
    // them to the main thread.
    private class FetchWeatherInfoTask extends AsyncTask<String, Void, String> {
        private String units;

        public FetchWeatherInfoTask(String units) {
            this.units = units;
        }

        @Override
        protected String doInBackground(String... params) {
            String capital = params[0];
            String apiKey = "d4cfbebfcb68d1365883f7a56d31e1bf";
            String url = "https://api.openweathermap.org/data/2.5/weather?q=" + capital + "&units=" + units + "&appid=" + apiKey;

            String CF;
            if (units.equals("Metric")) {
                CF = "Celcius";
            } else {
                CF = "Fahrenheit";
            }


            try {
                // Create a new RequestQueue using Volley library
                RequestQueue queue = Volley.newRequestQueue(ProfileActivity.this);

                // Create a new JsonObjectRequest for the weather information
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                        (Request.Method.GET, url, null, response -> {
                            try {
                                // Extract the temperature and description from the JSON response
                                JSONObject main = response.getJSONObject("main");
                                double temp = main.getDouble("temp");
                                String description = response.getJSONArray("weather").getJSONObject(0).getString("description");

                                // Set the temperature TextView with the weather information
                                String weatherInfo = "Temperature in " + capital + " is " + temp + " " + CF + ". Description: " + description;
                                tempTextView.setText(weatherInfo);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }, error -> {
                            // Handles the error if getting the weather information fails
                            String failWeather = "Error getting weather information, please check network connection";
                            tempTextView.setText(failWeather);
                            Log.e("ProfileActivity", "Error getting weather information, please check network connection");
                        });
                queue.add(jsonObjectRequest);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    // Calls FetchWeatherInfoTask class to fetch weather information
    // for a given capital city and a specified temperature units (metric or imperial)
    private void fetchWeatherInfo(String capital, String units) {
        new FetchWeatherInfoTask(units).execute(capital);
    }
}

